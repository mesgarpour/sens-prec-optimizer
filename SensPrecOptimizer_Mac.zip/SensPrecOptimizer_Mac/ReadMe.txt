/*
  
 * Copyright 2012 The Sensitivity and Precision Maximization (SPM) Authors.

 *

 * Licensed under the Apache License, Version 2.0 (the "License");

 * you may not use this file except in compliance with the License.

 * You may obtain a copy of the License at

 *

 *     http://www.apache.org/licenses/LICENSE-2.0

 *

 * Unless required by applicable law or agreed to in writing, software

 * distributed under the License is distributed on an "AS IS" BASIS,

 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

 * See the License for the specific language governing permissions and

 * limitations under the License.

 */




Installation and Setup:
1. Install the QT Creator (refer to the user manual)
2. Double click on the SensPrecOptimizer app. You might have to change the security level of the Mac OS in order to allow the application to run (System Preferences > Security & Privacy > General tab > Allow apps downloaded from ‘Anywhere’). 
